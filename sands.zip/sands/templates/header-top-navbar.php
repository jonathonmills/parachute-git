<header class="banner navbar navbar-default navbar-fixed-bottom" role="banner">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
<?php /*?>      <a class="navbar-brand" href="<?php echo home_url(); ?>/"><?php bloginfo('name'); ?></a>
<?php */?>    </div>

    <nav class="collapse navbar-collapse" role="navigation">
      <?php
        if (has_nav_menu('primary_navigation')) :
          wp_nav_menu(array('theme_location' => 'primary_navigation', 'menu_class' => 'nav navbar-nav'));
        endif;
      ?>
      
       <div class="navbar-right soc-med">
    	<a href="#" target="_blank" class="fa fa-twitter"></a>
       <a href="#" target="_blank" class="fa fa-facebook"></a>
       <a href="#" target="_blank" class="fa fa-tumblr"></a>
       <a href="#" target="_blank" class="fa fa-instagram"></a>
    </div>
    </nav>
    
</header>
