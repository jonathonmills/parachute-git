
<?php wp_footer(); ?>

<?php /*?><script>
$('#home-pictures-inner img').load(function() {
		imgWidth = $(this).width();
		if (imgWidth % 7 != 0) { // checks if the imgHeight is not dividable by 4
			$(this).animate({
				width: 	$(this).('img').attr("width") = Math.floor(imgWidth / 7) * 7
			});
		 }
});
</script><?php */?>

<script>

$(document).ready(function(){
resizeDiv();
});

window.onresize = function(event) {
resizeDiv();
}

function resizeDiv() {
vpw = $(window).width();
vph = $(window).height();
vphmod = vph - 97;
$('#home-pictures').css({'height': vphmod + 'px'});
}

</script>

<script>
enquire.register("screen and (min-width: 1025px)", {
    match : function() {
			$('#home-pictures').kinetic();

                $('#left').click(function(){
                    $('#home-pictures').kinetic('start', { velocity: -10 });
                });
                $('#right').click(function(){
                    $('#home-pictures').kinetic('start', { velocity: 10 });
                });
                $('#end').click(function(){
                    $('#home-pictures').kinetic('end');
                });
                $('#stop').click(function(){
                    $('#home-pictures').kinetic('stop');
                });
            
                $('#attach').click(function(){
                    $('#home-pictures').kinetic('attach');
                });
    },  
    unmatch : function() {
			   $('#detach').click(function(){
                    $('#home-pictures').kinetic('detach');
                });
    }
});
</script>

<script type="text/javascript">
$( window ).load( function(){
	$('#home-pictures-inner').masonry({
	  columnWidth: 1,
	  itemSelector: '.photo-link'
	});
	$('.loader').fadeTo( "slow" , 0, function() {
    	$('.loader').css( 'margin-left','-100%')
  	});	
	$('body').css( 'background-color','#fff')
	$('#home-pictures-inner').fadeTo( "50" , 1, function() {
  	});
	$(".main-logo").removeClass('rotate');
});

</script>


<script>
  jQuery(".modal-title").fitText(1.4, { minFontSize: '90px', maxFontSize: '123px' })
</script>

<script>
$('.modal').on('shown.bs.modal', function (e) {
	$(".modal-content").show(function(){
		$(this).find("img").prop("src", function(){
			return $(this).data("src");
		});
	});
    $('#home-pictures').kinetic('detach');
});
// stops the scrolling of the home page when a modal has been loaded

$('.modal').on('hidden.bs.modal', function (e) {
    $('#home-pictures').kinetic('attach');
});
// starts the scrolling of the home page when a modal has been closed
</script>

<script>
//script for ending the play function on a video when a modal
//is closed
$(document).ready(function(){
    $('.modal').each(function(){
        var src = $(this).find('iframe').attr('src');
		$(this).on('click', function(){
            $(this).find('iframe').attr('src', '');
            $(this).find('iframe').attr('src', src);
        });
    });
});

//script for loading in video content when modal
//is clicked. Increases load times by not loading 
//content at initialisation

$('a.photo-link').on('click', function(e) {
    var src = $(this).attr('data-src');
    var height = $(this).attr('data-height') || 720;
    var width = $(this).attr('data-width') || 1280;
	var modalno = $(this).attr('data-target');
    
    $(".modal iframe" ).attr({'src':src,
                        'height': height,
                        'width': width});
	$(".modal-body").fitVids(); //fits the video to the modal div
});

//</script>


