<?php
/*
Template Name: Home Template
*/
?>

<div class="loader"></div>

<div class="top-bar"></div><div class="left-bar"></div><div class="right-bar"></div>

<div class="main-logo rotate"></div>

<section id="home-pictures">

        <div id="home-pictures-inner">
        
        <?php
         
        // check if the repeater field has rows of data
        if( have_rows('home_photos') ):
         	 $count = 0;
            // loop through the rows of data
            while ( have_rows('home_photos') ) : the_row(); ?>

            <a class="photo-link" data-src="<?php if (get_sub_field('box_type') == 'video') {?><?php echo the_sub_field('video'); ?><?php } else { ?>#<?php }?>" data-toggle="modal" data-target="#myModal-<?php echo $count ?>">
                <span class="home-photo">
                    <img src="<?php the_sub_field('home_photo'); ?>">
         		 	<span class="hover">View <?php echo the_sub_field('box_type'); ?></span>
                </span>
            </a>
            
            
            <!-- Modal -->
            <div class="modal fade" id="myModal-<?php echo $count ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">Close <?php echo the_sub_field('box_title'); ?> <i class="fa fa-times"></i></button>
              <div class="modal-dialog modal-lg <?php echo the_sub_field('box_type'); ?>">
                <div class="modal-content">
                  <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel"><?php echo the_sub_field('box_title'); ?></h4>
                  </div>
                  <div class="modal-body">
                    	<?php if (get_sub_field('box_type') == 'video') {?>
                        <iframe frameborder="0" allowfullscreen></iframe>
                      <?php } ?>
                            
                      <?php if (get_sub_field('box_type') == 'collection') {?>
                      
                      <?php
 
						// check if the repeater field has rows of data
						if( have_rows('slider') ): ?>
                        
                         <!-- Controls -->
                          <a class="left carousel-control" href="#collection-slider" data-slide="prev">
                            <i class="fa fa-angle-left"></i></span>
                          </a>
                          <a class="right carousel-control" href="#collection-slider" data-slide="next">
                            <i class="fa fa-angle-right"></i></span>
                          </a> 

                        <div id="collection-slider" class="carousel slide" data-ride="carousel">
                        
                        <div class="carousel-inner">
                        
                        <?php $slidecount = 0 ?>

						   <?php  while ( have_rows('slider') ) : the_row(); ?>
                           
                           	<?php $attachment_id = get_sub_field('slide_picture');
								$size = "collection-image"; // (thumbnail, medium, large, full or custom size)
								$profileimage = wp_get_attachment_image_src( $attachment_id, $size );?>
                                                            
                             <div class="<?php if($slidecount=='1'){ echo 'active' ; } ?> item">
                                <div class="slider-info">
                                
                                <div class="slider-info-inner">
                                    <h3><?php the_sub_field('slide_title'); ?></h3>
                                    <div class="slide-text"><?php the_sub_field('slide_text'); ?></div>
                                </div>
   
                                </div>
                                <div class="slider-image">
									<img src="<?php echo $profileimage[0]; ?>" />
                                 </div> 
                                <div class="slider-thumbs">
                                <?php if(get_field('slider')): ?>
                                  <ol class="carousel-indicators hidden-sm hidden-xs">
                                        <?php $count = 0 ?>
                                        <?php while(has_sub_field('slider')): ?>
                                        <li data-target="#collection-slider" data-slide-to="<?php echo $count ?>" class="<?php if($count=='1'){ echo 'active' ; } ?>"></li>
                                         <?php $count++; endwhile;?>
                                    </ol>     
                                    <?php endif; ?>
                                </div>    
                            </div>   
						 
							<?php $slidecount ++; endwhile; ?>

                         </div>   
 
                         </div>
						 
						<?php else :
						 
							// no rows found
						 
						endif;
						 
						?>
      
                     <?php } ?>
                  </div>
                </div>
              </div>
            </div>
         
            <?php $count++; endwhile;
         
        else :
         
            // no rows found
         
        endif;
         
        ?>
        
        </div>
     
</section>